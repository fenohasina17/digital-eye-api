
<!--begin::Page loader-->
		<div class="page-loader page-loader-logo">
			<img alt="Logo" class="max-h-75px" src="{{ asset($logo) }}" />
			<div class="spinner spinner-primary"></div>
		</div>

		<!--end::Page Loader-->