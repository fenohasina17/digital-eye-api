@extends('admin.layouts.master')
@section('title',$title)
@section('content')

    <div class="container">
        <div class="row">

        </div>
    </div>
@endsection

@section('scripts')

@endsection
